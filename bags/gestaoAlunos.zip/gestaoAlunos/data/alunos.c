
/* ---------------------------------
   alunos.c
           2016-05-17 by jcr
   --------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "alunos.h"

void listTurma(Turma t)
{
  while(t)
  {
    showAluno(t->a);
    t = t->seg;
  }
}

void showAluno( Aluno a )
{
  printf("%7s %30s %10s\n", a.id, a.nome, a.curso );
}

int countAlunos( Turma t )
{
  int count=0;
  while(t)
    {
      count++;
      t = t->seg;
    }
  return count;
}

Turma searchAluno( Turma t, char *id )
{
  int found=0;

  while(t && !found)
  {
    if(strcmp( id, t->a.id ) == 0)
    {
      found = 1;
    }
    else
      t = t->seg;
  }
  return t;
}

Turma addAluno( Turma t, Aluno a )
{
  Turma new;

  if(!t)
    {
      new = (Turma)malloc(sizeof(NodoTurma));
      new->a = a; 
      new->seg = t;
      t = new;
    }
  else
    {
      if(strcmp(a.nome,t->a.nome)>0)
        t->seg = addAluno( t->seg, a );
      else
        {
          new = (Turma)malloc(sizeof(NodoTurma));
          new->a = a; 
          new->seg = t;
          t = new;
        }
    }

  return t;
}

int saveAlunos( Turma t )
{ 
  int count=0;
  FILE *f;

  f = fopen("ALUNOS.DAT","w");
  while(t)
  {
    fwrite( &(t->a), sizeof(Aluno), 1, f);
    t = t->seg;
    count++;
  }

  fclose(f);
  return count;
}

int prettySaveAlunos( Turma t )
{ 
  int count=0;
  FILE *f;

  f = fopen("ALUNOS.TXT","w");
  while(t)
  {
    fprintf( f, "%s;%s;%s\n", t->a.id, t->a.nome, t->a.curso );
    t = t->seg;
    count++;
  }

  fclose(f);
  return count;
}

Turma prettyLoadAlunos()
{
  Turma t=NULL;
  Aluno a;
  FILE *f;
  char temp[100];

  f = fopen("ALUNOS.TXT","r");

  while(fgets( temp, 100, f)) 
    {
      strcpy( a.id, strtok(temp, ";"));
      strcpy( a.nome, strtok(NULL, ";"));
      strcpy( a.curso, strtok(NULL, ";"));
      t = addAluno(t,a);
    }
    
  fclose(f);
  return t;
}


Turma loadAlunos()
{
  Turma t=NULL;
  Aluno a;
  FILE *f;

  f = fopen("ALUNOS.DAT","r");

  while( fread( &(a), sizeof(Aluno), 1, f) )
    t = addAluno(t,a);
  fclose(f);
  return t;
}


Turma freeTurma(Turma t)
{
  if(t)
  {
    freeTurma(t->seg);
    free(t);
  }
  return NULL;
}


