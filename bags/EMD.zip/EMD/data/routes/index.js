var express = require('express');
var router = express.Router();
var Exame = require('../controllers/exame')

router.get('/emd', function(req, res) {
    Exame.list()
      .then(dados => res.status(200).json(dados))
      .catch(erro => res.status(520).json({erro: erro, mensagem: "Erro na listagem dos EMD."}))
});

router.get('/emd/:id', function(req, res) {
  Exame.getExame(req.params.id)
    .then(dados => res.status(200).json(dados))
    .catch(erro => res.status(521).json({erro: erro, mensagem: "Erro na recuperação dum EMD."}))
});

router.get('/emd/distrib/modalidade', function(req, res) {
  Exame.distribModalidade()
    .then(dados => res.status(200).json(dados))
    .catch(erro => res.status(525).json({erro: erro, mensagem: "Erro na distribuição por modalidade."}))
})

router.get('/emd/distrib/genero', function(req, res) {
  Exame.distribGenero()
    .then(dados => res.status(200).json(dados))
    .catch(erro => res.status(525).json({erro: erro, mensagem: "Erro na distribuição por modalidade."}))
})

router.post('/emd', (req, res) => {
  Exame.addExame(req.body)
    .then(dados => res.status(201).json(dados))
    .catch(erro => res.status(522).json({erro: erro, mensagem: "Erro na inserção dum EMD."}))
})

router.delete('/emd/:id', function(req, res) {
  Exame.deleteExame(req.params.id)
    .then(dados => res.status(200).json(dados))
    .catch(erro => res.status(523).json({erro: erro, mensagem: "Erro na remoção dum EMD."}))
});

router.put('/emd/:id', function(req, res) {
  Exame.updateExame(req.params.id, req.body)
    .then(dados => res.status(200).json(dados))
    .catch(erro => res.status(524).json({erro: erro, mensagem: "Erro na alteração dum EMD."}))
});

module.exports = router;
