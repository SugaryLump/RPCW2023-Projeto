var Exame = require('../models/exame')

module.exports.list = () => {
    return Exame
        .find({}, {nome:1, dataEMD:1, resultado:1})
        .sort({dataEMD:-1})
        .then(dados => {
            return dados
        })
        .catch(erro => {
            return erro
        })
}

module.exports.getExame = id => {
    return Exame
        .findOne({_id:id})
        .then(dados => {
            return dados
        })
        .catch(erro => {
            return erro
        })
}

module.exports.addExame = e => {
    return Exame
        .create(e)
        .then(dados => {
            return dados
        })
        .catch(erro => {
            return erro
        })
}

module.exports.deleteExame = id => {
    return Exame
        .deleteOne({_id:id})
        .then(dados => {
            return dados
        })
        .catch(erro => {
            return erro
        })
}

module.exports.updateExame = (id, e) => {
    return Exame
        .updateOne({_id:id}, e)
        .then(dados => {
            return dados
        })
        .catch(erro => {
            return erro
        })
}


module.exports.distribModalidade = () => {
    return  Exame
                .aggregate([ { $group : { _id : "$modalidade", total: {$count: {}}}}])
                .sort({total: -1})
                .exec()
}

module.exports.distribGenero = () => {
    return  Exame
                .aggregate([ { $group : { _id : "$género", total: {$count: {}}}}])
                .sort({total: -1})
                .exec()
}